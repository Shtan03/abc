'use strict';

import Lang from '../../utils/lang.js';
import Array from '../../utils/array.js';
import Dom from '../../utils/dom.js';
import Widget from '../../ui/widget.js';


export default Lang.Templatable("DevsDiagram.DevsDiagram", class DevsDiagram extends Widget { 

	constructor(file) {
		super();

		this.Node('diagram').innerHTML = file;
	}
	
	Template() {
		return "<div class='devsDiagram'>" + 
				  "<div handle='title' class='diagram-title'>nls(DevsDiagram_Title)</div>" + 
				  "<div handle='diagram' class='diagram-container' id='file-content'></div>" +
				  
			   "</div>";
	}

	Resize(dimensions) {
	this.dimensions = dimensions;
		this.size = Dom.Geometry(this.Node("canvas-container"));

		var cW = Math.floor(this.size.w / this.dimensions.x);
		var cH = Math.floor(this.size.h / this.dimensions.y);
		
		// Find best fit cell size
		this.cell = cW < cH ? cW : cH; 
		
		// Determine offset w, h to center grid as much as possible
		var pH = (this.size.w - (this.dimensions.x * this.cell)) / 2;
		var pV = (this.size.h - (this.dimensions.y * this.cell)) / 2;
		
		this.Node("canvas").style.margin = `${pV}px ${pH}px`;		
		
		// Redefine with and height to fit with number of cells and cell size
		this.Node("canvas").width = this.dimensions.x * this.cell;	
		this.Node("canvas").height = this.dimensions.y * this.cell;		
	
	}
	
	Draw() {
		
	}
	
	Clear() {

	}
	
	DrawState() {	

	}
});