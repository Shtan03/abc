'use strict';

import Lang from '../../utils/lang.js';
import Array from '../../utils/array.js';
import Dom from '../../utils/dom.js';
import Diagram from './diagram.js';
import Automated from '../automated.js';



export default Lang.Templatable("Auto.DevsDiagram", class AutoDevsDiagram extends Automated { 

	constructor(config, simulation) {
		super(new Diagram(config.svg), simulation);

		var h = this.Simulation.On("Jump", this.onSimulationJump_Handler.bind(this));
		var h = this.Simulation.On("Move", this.onSimulationMove_Handler.bind(this));


	//	 var fileReader = new FileReader();
		// fileReader.readAsText(inputFile, "UTF-8");
		 // var svg;
		 //fileReader.onload = function(){
		//svg = fileReader.result;
		//console.log(svg);
	  //};
	
		this.Handle([h]);
	}
	
	Destroy() {
		super.Destroy();
	}
	
	Refresh() {
	this.Resize();
		this.Draw();

	}

		Resize() {
		this.Widget.Resize(this.Simulation.Size);
	}

	Draw() {

	}
	
	onSimulationMove_Handler(ev) {
		debugger;
	}

	onSimulationJump_Handler(ev) {
		debugger;
	}
	
	Save() {
		return { name:"Auto.DevsDiagram", config:{ }}
	}

});