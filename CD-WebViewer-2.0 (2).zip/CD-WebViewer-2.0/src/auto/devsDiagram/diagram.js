'use strict';

import Lang from '../../utils/lang.js';
import Array from '../../utils/array.js';
import Dom from '../../utils/dom.js';
import Widget from '../../ui/widget.js';


export default Lang.Templatable("DevsDiagram.DevsDiagram", class DevsDiagram extends Widget { 

	constructor(file) {
		super();

		this.Node('diagram').innerHTML = file;
	}
	
	Template() {
		return "<div class='devsDiagram'>" + 
				  "<div handle='title' class='diagram-title'>nls(DevsDiagram_Title)</div>" + 
				  "<div handle='diagram' class='diagram-container'></div>" +
			   "</div>";
	}

	Resize(dimensions) {
	
	}
	
	Draw() {
		
	}
	
	Clear() {

	}
	
	DrawState() {	

	}
});