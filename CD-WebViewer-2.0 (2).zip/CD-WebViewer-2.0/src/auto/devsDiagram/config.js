'use strict';

import Lang from '../../utils/lang.js';
import Array from '../../utils/array.js';
import Dom from '../../utils/dom.js';
import Widget from '../../ui/widget.js';

//const SVG = '<svg width="580" height="400" xmlns="http://www.w3.org/2000/svg"> <!-- Created with Method Draw - http://github.com/duopixel/Method-Draw/ --> <g>  <title>background</title>  <rect fill="#fff" id="canvas_background" height="402" width="582" y="-1" x="-1"/>  <g display="none" overflow="visible" y="0" x="0" height="100%" width="100%" id="canvasGrid">   <rect fill="url(#gridpattern)" stroke-width="0" y="0" x="0" height="100%" width="100%"/>  </g> </g> <g>  <title>Layer 1</title>  <rect id="svg_1" height="52" width="110" y="53.05" x="59.5" stroke-width="1.5" stroke="#000" fill="#fff"/>  <rect id="svg_2" height="36" width="103" y="63.05" x="278.5" stroke-width="1.5" stroke="#000" fill="#fff"/>  <rect id="svg_3" height="37" width="99" y="157.05" x="171.5" stroke-width="1.5" stroke="#000" fill="#fff"/>  <rect id="svg_4" height="70" width="118" y="167.05" x="342.5" stroke-width="1.5" stroke="#000" fill="#fff"/>  <line stroke="#000" stroke-linecap="undefined" stroke-linejoin="undefined" id="svg_5" y2="78.05" x2="168.5" y1="82.05" x1="281.500002" stroke-width="1.5" fill="none"/>   </g></svg>'

export default Lang.Templatable("Config.DevsDiagram", class ConfigDevsDiagram extends Widget { 

	constructor() {
		super();
		
		this.Node("continue").addEventListener("click", this.onLoadClick_Handler.bind(this));
		
				
		var name = Lang.Nls("Widget_AutoDevsDiagram");
	
	
		this.Node("title").innerHTML = Lang.Nls("Configurator_Title", [name]);
	}
	
		onLoadClick_Handler(ev) {		
		 var fileInput = document.getElementById ("myFile").files[0];
		 var svg;
		 var fileReader = new FileReader();
  fileReader.onload = function(fileLoadedEvent){
      var textFromFileLoaded = fileLoadedEvent.target.result;
     svg = textFromFileLoaded;
	  console.log(textFromFileLoaded);
  };

  fileReader.readAsText(fileInput, "UTF-8");
		 	

	//	}
		
	//	this.Emit("Configured", { configuration:configuration });
	}
	
	Save() {
		return { name:"Config.diagram" };
	}

	
	Template() {
		
	return "<div class='configuration'>" + 
				   "<div handle='title' class='configuration-title'></div>" + 
				   "<div class='configuration-line'>" + 
					  "<div class='label'>nls(DevsDiagram_Title)</div>" +
					  " <input type='file' name='Filename' id ='myFile'>" +
				   "</div>" +
				   "<button handle='continue' class='load'>nls(Configurator_Continue)</button>" + 
			   "</div>";
			   
			   
	}

		
	
});