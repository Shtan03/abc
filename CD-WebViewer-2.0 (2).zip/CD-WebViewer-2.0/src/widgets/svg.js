'use strict';

import Lang from '../utils/lang.js';
import Array from '../utils/array.js';
import Dom from '../utils/dom.js';
import Widget from '../ui/widget.js';
import SVG from '../utils/svg.js';

window.onload=function() {
	// Get the Object by ID
	var a = document.getElementById("svg-object");
	console.log(a);
	
	// Get the SVG document inside the Object tag
	var svgDoc = a.getSVGDocument();
	console.log(svgDoc);
	// Get one of the SVG items by ID;
	var svgItem = svgDoc.getElementById("svg_1");
	// Set the colour to something else
	svgItem.setAttribute("fill", "#f03");
};