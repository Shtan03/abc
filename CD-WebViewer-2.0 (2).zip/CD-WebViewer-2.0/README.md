# CD-WebViewer-2.0
Second version of the CD-WebViewer.

Give it a try : https://simulationeverywhere.github.io/CD-WebViewer-2.0/index.html

(Note : When we abandon the first version, we should delete the previous repo and rename this one)
